
import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  products: any[] = [];
  filteredProducts: any[] = [];
  appleProducts: any[] = [];

  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.productService.getProducts().subscribe((data: any) => {
      this.products = data.products; // Access products from data
      this.filteredProducts = this.products.filter(product => product.discountPercentage > 10 || product.price > 1000);
      this.appleProducts = this.products.filter(product => product.brand.toLowerCase() === 'apple');
    });
  }
}
