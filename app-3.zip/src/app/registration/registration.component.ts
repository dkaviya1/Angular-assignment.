import { Component } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {

  user = {
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  };

  register() {
    // Replace this with your actual registration logic
    console.log('User registered:', this.user);
  }
}
