import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IfloopComponent } from './ifloop.component';

describe('IfloopComponent', () => {
  let component: IfloopComponent;
  let fixture: ComponentFixture<IfloopComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IfloopComponent]
    });
    fixture = TestBed.createComponent(IfloopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
