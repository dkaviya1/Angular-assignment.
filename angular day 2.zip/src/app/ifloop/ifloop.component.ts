import { Component } from '@angular/core';

@Component({
  selector: 'app-ifloop',
  templateUrl: './ifloop.component.html',
  styleUrls: ['./ifloop.component.css']
})
export class IfloopComponent {
  people: any[] = [ 

    {
    
    "name": "Tobia",
    "age" :32
    },
    {
    
    "name": "Alex",
    "age" :36
  },
  {
    
    "name": "Brad Green",
    "age" :38
    
    }]
    
  

}


