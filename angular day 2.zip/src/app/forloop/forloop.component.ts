import { Component } from '@angular/core';

@Component({
  selector: 'app-forloop',
  templateUrl: './forloop.component.html',
  styleUrls: ['./forloop.component.css']
})
export class ForloopComponent {
  people: any[] = [ 

    {
    
    "name": "Tobia"
    
    },
    {
    
    "name": "Alex"
  },
  {
    
    "name": "Brad Green"
    
    }]
    
  

}
