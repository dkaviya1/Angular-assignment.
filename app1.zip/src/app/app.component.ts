import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app1';
  fahrenheitTemperature: number = 0; // Replace with your Fahrenheit temperature
  celsiusTemperature: number = 0;
  originalString:string='';
}
