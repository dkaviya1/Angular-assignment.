import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CountryComponent } from './country/country.component';
import { CountrySortPipe } from './country-sort.pipe';
import { ReverseStringPipe } from './reverse-string.pipe';
import { TemperatureConversionPipe } from './temperature.pipe';


@NgModule({
  declarations: [
    AppComponent,
    CountryComponent,
    CountrySortPipe,
    ReverseStringPipe,
    TemperatureConversionPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

