import { Directive,HostListener } from '@angular/core';

@Directive({
  selector: '[appNoWhitespace]'
})
export class NoWhitespaceDirective {

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    if (event.key === ' ') {
      event.preventDefault();
    }
  }


}
