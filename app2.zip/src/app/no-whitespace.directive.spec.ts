import { NoWhitespaceDirective } from './no-whitespace.directive';

describe('NoWhitespaceDirective', () => {
  it('should create an instance', () => {
    const directive = new NoWhitespaceDirective();
    expect(directive).toBeTruthy();
  });
});
